function examplewait()
% EXAMPLEWAIT   Auxiliary function for examples - Wait for user input
%
% EXAMPLEWAIT() waits until a key is pressed.

%   Author: Giovanni Volpe
%   Revision: 1.0.0  
%   Date: 2015/01/01

input('Press key to continue')
fprintf('\n')
fprintf('\n')
fprintf('\n')