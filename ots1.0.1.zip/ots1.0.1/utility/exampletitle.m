function exampletitle(title)
% EXAMPLETITLE   Auxiliary function for examples - Display title
%
% EXAMPLETITLE(TITLE) displays TITLE.

%   Author: Giovanni Volpe
%   Revision: 1.0.0  
%   Date: 2015/01/01

fprintf(['\n<strong>' title '</strong>\n'])